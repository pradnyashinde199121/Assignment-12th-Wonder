import { Component, OnInit } from '@angular/core';
import{MyserviceService} from './myservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  myCount:number;
  teamCount:number;
  title = 'project1';
  constructor(private myservice:MyserviceService) {
    
  } 
  ngOnInit() {
    this.myservice.currentMyTask.subscribe(result => this.myCount = result)
    this.myservice.currentTeamTask.subscribe(result => this.teamCount = result)
  }
}
