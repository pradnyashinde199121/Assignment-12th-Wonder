import { Component, OnInit } from '@angular/core';
import{MyserviceService} from '../myservice.service';
import {MatTableDataSource} from '@angular/material/table';


@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  private newAttribute: any = [];
  addFieldValue() {
    if(this.newAttribute.text != undefined  ){
      this.emp1.push(this.newAttribute)
      this.newAttribute = {};
    }
    else(alert("add some value"))
  }
  checked = false;
  indeterminate = false;
  labelPosition = 'after';
  disabled = false;
  message:string
  showHideAlert: boolean;
private emp: any =[];
public type:any;
public private: any;
public emp1 :any=[];

LeaderData :any[];
OtherData :any[];
GlobalData :any[];
completedTaskData: any=[];
  constructor(private myservice:MyserviceService) { 
    
    this.emp1 = this.emp.slice();
  }

  tasktype(filtertext:string){
    {
      this.myservice.getdata().subscribe(data => {
        if(filtertext=== 'Globel')
        {this.emp1=data.filter(emp=>emp.isGlobal== true);}
        else if(filtertext=== 'Leader')
        {this.emp1=data.filter(emp=>emp.isLeader== true);}
        else if(filtertext=== 'Personel')
        {this.emp1=data.filter(emp=>emp.isGlobal== false && emp.isLeader== false);}
        else
        { this.emp1= data}
       } );
       }
  }
 
  ngOnInit() {
    this.tasktype('ALL');
    
  }
  completedTask(data : any) {
  
    if(data.isCompleted=== false){
      data.isCompleted =true;
      this.completedTaskData.push(data);
      if(data.isGlobal==false && data.isLeader==false){
        this.myservice.changeMyCount(this.completedTaskData.filter(x=>x.isGlobal==false && x.isLeader==false).length);
      
      }
      else{
        this.myservice.changeTeamCount(this.completedTaskData.filter(x=>x.isGlobal==true || x.isLeader==true).length); 
      }
      this.showHideAlert = true;
     this.message = data.text;

    }
    else{
      data.isCompleted = false;
      this.completedTaskData.pop(data);
      if(data.isGlobal==false && data.isLeader==false){
        this.myservice.changeMyCount(this.completedTaskData.filter(x=>x.isGlobal==false && x.isLeader==false).length);
      }
      else{
        this.myservice.changeTeamCount(this.completedTaskData.filter(x=>x.isGlobal==true || x.isLeader==true).length); 
      }
      this.showHideAlert = false;
      this.message = '';

    }
    
  }
  dataSource = new MatTableDataSource(this.emp1);

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  sortData(sort: any) {
    const data = this.emp1.slice();
    if (!sort.active || sort.direction === '') {
      this.emp1 = data;
      return;
    }
    
    this.emp1 = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'text': return compare(a.text, b.text, isAsc);
        case 'isGlobal': return compare(a.isGlobal, b.isGlobal, isAsc);
        case 'isLeader': return compare(a.isLeader, b.isLeader, isAsc);
        case 'creator': return compare(a.creator, b.creator, isAsc);
        case 'isCompleted': return compare(a.isCompleted, b.isCompleted, isAsc);
        case 'start': return compare(a.start, b.start, isAsc);
        case 'end': return compare(a.end, b.end, isAsc);
        
        default: return 0;
      }
    });
  }
}

function compare(a: number | string, b: number | string, isAsc: boolean) {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
 
}


