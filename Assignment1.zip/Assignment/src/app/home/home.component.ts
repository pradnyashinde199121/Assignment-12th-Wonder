import { Component, OnInit } from '@angular/core';
import{MyserviceService} from '../myservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  myCount:number;
  teamCount:number;
  public emp1 :any=[];
private emp: any =[];
LeaderData :any[];
OtherData :any[];
GlobalData :any[];
  constructor(private myservice:MyserviceService) {
    
   } 
   loading=true;

  ngOnInit() {
    
    
    {
      this.myservice.getdata().subscribe(data => {
        this.GlobalData=data.filter(emp=>emp.isGlobal== true);
        this.LeaderData=data.filter(emp=>emp.isLeader== true);
        this.OtherData=data.filter(emp=>emp.isGlobal== false && emp.isLeader== false);
       } );
       }
 
        setTimeout (() => {
        this.loading=false;
              }, 1000);
      
  }


}
