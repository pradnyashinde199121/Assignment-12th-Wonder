import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  private myTaskCount = new BehaviorSubject(0);
   currentMyTask = this.myTaskCount.asObservable();
   private teamTaskCount = new BehaviorSubject(0);
   currentTeamTask = this.teamTaskCount.asObservable();
   
   changeMyCount(count:number) {
    this.myTaskCount.next(count)
  }
  changeTeamCount(count:number) {
    this.teamTaskCount.next(count)
  }

   
   public url:string = "/assets/pkg.json";
  constructor(private _http:HttpClient ) {

   }
   getdata():Observable<any>{
     return this._http.get<any>(this.url)
   }
   
}
